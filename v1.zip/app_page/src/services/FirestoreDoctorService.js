import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebaseConfig.js';

// ============================================================================
// BROWSER-ONLY. The doctor counterpart to FirestoreUserService.js -- same
// "one seam, pure engines everywhere else" convention. useDoctorAuth.js is
// the only caller.
//
// Kept as a SEPARATE Firestore collection (/doctors/{uid}, not /users/{uid})
// so a doctor record and a patient record never collide even though (see
// useDoctorAuth.js's 2026-08-18 header comment) they share the same
// underlying Firebase Authentication user pool.
//
// 2026-08-18: createdAt/updatedAt added via serverTimestamp() -- same
// reasoning as FirestoreUserService.js's header comment (server-side clock,
// not the device's).
// ============================================================================
function doctorDocRef(uid) {
  return doc(db, 'doctors', uid);
}

export const FirestoreDoctorService = {
  async getDoctorProfile(uid) {
    const snap = await getDoc(doctorDocRef(uid));
    return snap.exists() ? snap.data() : null;
  },

  async createDoctorProfile(uid, profileDoc) {
    const withTimestamps = { ...profileDoc, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await setDoc(doctorDocRef(uid), withTimestamps);
    return profileDoc;
  },

  async updateDoctorProfile(uid, partialUpdate) {
    await updateDoc(doctorDocRef(uid), { ...partialUpdate, updatedAt: serverTimestamp() });
  },
};
