// The patient app's top-level navigation.
//
// 2026-08-18: expanded from 5 sections to 9. The original 5 were real, but
// "My Progress" had quietly grown into one card bundling six different
// views (trend charts, domain breakdown, activity heatmap, clinical
// insights, and the report download) -- functional, but it meant most of
// this app's real content was invisible in the nav itself. Split into its
// own section per real view rather than inventing anything new: Domains,
// Activity, Insights, and Reports below are the exact same
// components/data that used to live inside ProgressSection.jsx, just each
// promoted to its own top-level item (see DomainsSection.jsx /
// ActivitySection.jsx / InsightsSection.jsx / ReportsSection.jsx).
export const SECTIONS = [
  {
    id: 'home',
    label: 'Home',
    description: "Today's tasks, your streak, and today's Momentum Score.",
  },
  {
    id: 'assessment',
    label: 'Detection Assessment',
    description: 'Your weekly cognitive check-in -- Lobar Function Test plus 10 rotating questions.',
  },
  {
    id: 'games',
    label: 'Improvisation Games',
    description: 'Daily improvisation games -- Memory, Reaction, Attention, Speech, Facial Expressivity.',
  },
  {
    id: 'progress',
    label: 'My Progress',
    description: 'Your weekly and monthly cognitive score trend, plus your daily Momentum Score history.',
  },
  {
    id: 'domains',
    label: 'Domains',
    description: 'How you\'re tracking across each cognitive domain the Detection Assessment measures.',
  },
  {
    id: 'activity',
    label: 'Activity',
    description: 'Your Daily Set activity over the last 12 weeks, at a glance.',
  },
  {
    id: 'insights',
    label: 'Insights',
    description: "What's changed recently, in plain language.",
  },
  {
    id: 'reports',
    label: 'Reports',
    description: 'Download a printable summary of your latest results.',
  },
  {
    id: 'morphy',
    label: 'Chat with Morphy',
    description: 'Ask Morphy anything -- doubts, help, or errors.',
  },
];

export const SECTION_KEYS = SECTIONS.map((s) => s.id);
