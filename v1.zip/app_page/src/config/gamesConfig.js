// Status is deliberately three-valued, not just "ready / coming soon" --
// several of these modules were already built as their own NEUROMORPH
// projects, but not every one is connected/wired into this app yet.
// Collapsing "built elsewhere, not wired in yet" into "coming soon" would
// understate real progress; collapsing it into "ready" would overclaim what
// this app can actually launch today. See README "What's real vs. mocked".
//
// 2026-08-14 correction: this file previously (incorrectly) listed Visual
// Memory Test / Delayed Recognition Test / Face Recognition Test as the
// daily "Memory" category's sub-games. Confirmed with the product owner:
// those three are part of the WEEKLY Detection Assessment (Final 8, tracks
// lobe function) and are a completely separate thing from the daily
// Memory/Reaction/Attention rotating games, which use their own, different
// game content (2 games per category, not yet sent). Removed the stale
// cross-reference so a patient never sees what looks like the same memory
// test counted twice under two different scores.
//
// 2026-08-19: Memory/Reaction/Attention are no longer "Optional Games" --
// per the new Daily Set spec (dailyTaskConfig.js), all 3 are now MANDATORY
// daily items, each rotating between exactly 2 named sub-games (real
// identity/labels below, real gameplay still pending -- "except that
// improvization games" stays out of scope for this pass). Each sub-game now
// has a stable `id` (not just a label string) so DailyGameRotationEngine.js
// can deterministically pick "today's" one and so completion/analytics can
// eventually reference a specific sub-game, not just its category. The
// standalone 'speech' category entry was removed -- it duplicated the
// already-mandatory 'speech' Daily Set item and contributed nothing (its
// subGames list was always empty).
export const GAME_CATEGORIES = [
  {
    id: 'memory',
    label: 'Memory',
    subGames: [
      { id: 'memory-pattern-recall', label: 'Pattern Recall' },
      { id: 'memory-object-match', label: 'Object Match' },
    ],
    status: 'not-built',
  },
  {
    id: 'reaction',
    label: 'Reaction',
    subGames: [
      { id: 'reaction-quick-tap', label: 'Quick Tap' },
      { id: 'reaction-color-switch', label: 'Color Switch' },
    ],
    status: 'not-built',
  },
  {
    id: 'attention',
    label: 'Attention',
    subGames: [
      { id: 'attention-sustained-focus', label: 'Sustained Focus' },
      { id: 'attention-distraction-filter', label: 'Distraction Filter' },
    ],
    status: 'not-built',
  },
];

// The modules actually connected and embedded in the Daily Set player
// today. 'facial-expressivity' is the real teammate project (face_module),
// fully embedded (not a separate dev server link) -- calibrates against the
// patient's own resting face, then measures response to a few short
// camera-based prompts. Never records or stores video/images.
export const CONNECTED_GAMES = [
  {
    id: 'facial-expressivity',
    label: 'Facial Expressivity Test',
    category: 'Facial Expressivity',
    description: 'A short, camera-based check-in -- follow on-screen prompts while your facial expressivity is measured. No video is ever recorded or stored.',
  },
];
