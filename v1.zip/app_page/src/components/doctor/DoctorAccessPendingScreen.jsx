// The app_page counterpart to Doctor_Dashboard's AccessPendingScreen.jsx.
// 2026-08-19: with real Firebase doctor auth (useDoctorAuth.js) now live and
// self-healing accessApproved to true for every account (see that file's
// ACCESS-APPROVAL SCOPE NOTE / BUG FIX comments), this screen should no
// longer actually trigger in practice -- it's left in place, unremoved, for
// the day a real admin-review step replaces the current "no real backend
// yet" placeholder and this gate becomes meaningful again.
export default function DoctorAccessPendingScreen({ doctor, onLogout }) {
  return (
    <div className="nmpa-session-loading" role="status">
      <p className="nmpa-brand-mark nmpa-brand-mark--lg">NEUROMORPH</p>
      <div className="nmpa-card" style={{ maxWidth: 480, textAlign: 'left' }}>
        <h1 className="nmpa-card__title">Access not set up yet</h1>
        <p className="nmpa-muted">
          You're signed in as <strong>{doctor?.email}</strong>, but this account isn't yet approved to view patient
          data.
        </p>
        <p className="nmpa-muted nmpa-muted--sm">
          Signing in doesn't automatically grant patient data access -- an administrator must add your account
          first. This mirrors the same approval gate used in the full Doctor Dashboard. Once approved, sign out
          and back in to pick up access.
        </p>
        <button type="button" className="nmpa-button nmpa-button--secondary" onClick={onLogout}>Sign out</button>
      </div>
    </div>
  );
}
