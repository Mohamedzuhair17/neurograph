import { useEffect, useRef, useState } from 'react';
import { isGoogleMapsConfigured, loadGooglePlacesLibrary } from '../../config/googleMapsConfig.js';

// 2026-08-21: renders Google's live PlaceAutocompleteElement (a real
// worldwide city/state/country search -- type "Bangalore" and it offers
// "Bengaluru, Karnataka, India" the same way Google Maps' own search does)
// for OnboardingStep's 'placeAutocomplete' field type. See
// GOOGLE_PLACES_SETUP.md for the API key this needs.
//
// DESIGN NOTE: PlaceAutocompleteElement is a native web component with its
// own internal shadow-DOM text field -- it doesn't behave like a normal
// controlled React <input> (there's no clean, documented way to preset its
// visible text from a value prop, e.g. if a user navigates back to this
// step). Rather than fight that, this component keeps the same
// value/onChange contract every other OnboardingStep field uses as the
// single source of truth, and shows it back explicitly as a "Selected: "
// line below the search box -- so what's actually stored is always
// visible, regardless of what the widget's own input currently shows.
// Known, accepted limitation: clearing the text inside the widget's own
// box does NOT clear the stored value by itself -- only picking a new
// real suggestion updates it. Fine for a region field that's set once,
// not worth over-engineering under a hackathon deadline.
//
// FALLBACK: if VITE_GOOGLE_MAPS_API_KEY isn't set (or the script fails to
// load), this renders a plain text input instead -- same
// graceful-degradation posture as GoogleSignInButton's "(setup needed)"
// state. A doctor can always type their region manually either way.
export default function PlaceAutocompleteField({ value, onChange, placeholder, ariaInvalid }) {
  const containerRef = useRef(null);
  const [status, setStatus] = useState(isGoogleMapsConfigured ? 'loading' : 'unconfigured');

  useEffect(() => {
    if (!isGoogleMapsConfigured || !containerRef.current) return undefined;
    let cancelled = false;
    let element = null;
    let listener = null;

    loadGooglePlacesLibrary()
      .then(({ PlaceAutocompleteElement }) => {
        if (cancelled || !containerRef.current) return;
        element = new PlaceAutocompleteElement();
        containerRef.current.appendChild(element);
        listener = async ({ placePrediction }) => {
          const place = placePrediction.toPlace();
          await place.fetchFields({ fields: ['formattedAddress'] });
          onChange(place.formattedAddress || '');
        };
        element.addEventListener('gmp-select', listener);
        setStatus('ready');
      })
      .catch(() => {
        if (!cancelled) setStatus('error');
      });

    return () => {
      cancelled = true;
      if (element && listener) element.removeEventListener('gmp-select', listener);
      if (element && element.parentNode) element.parentNode.removeChild(element);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- onChange is OnboardingStep's stable per-field callback, mount-once by design
  }, []);

  if (status === 'unconfigured' || status === 'error') {
    return (
      <>
        <input
          type="text"
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          aria-invalid={ariaInvalid}
        />
        <span className="nmpa-muted nmpa-muted--sm">
          {status === 'error'
            ? "Live place search failed to load -- you can still type your region manually."
            : "Live place search isn't set up yet -- you can still type your region manually."}
        </span>
      </>
    );
  }

  return (
    <>
      <div ref={containerRef} className="nmpa-place-autocomplete" />
      <span className="nmpa-muted nmpa-muted--sm">
        {value ? `Selected: ${value}` : 'Search and pick your city, state, or country above.'}
      </span>
    </>
  );
}
