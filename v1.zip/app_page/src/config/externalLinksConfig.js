// External links referenced from inside the app -- kept as data, not
// hardcoded in a component, so wiring in the real marketing site (or
// changing it later, any number of times) is a one-line edit here, never a
// component change.
//
// 2026-08-17: real URL added (Team NEXUM's NeuroTrack marketing site,
// confirmed live). AuthTopBar.jsx's disabled/"coming soon" fallback only
// kicks in when this is empty, so the About button on the login/signup
// screens now opens this in a new tab. Site content/team profiles can be
// edited on the Vercel project directly, anytime, independent of this app
// -- this app only ever links out to it, never embeds or caches it.
export const ABOUT_WEBSITE_URL = 'https://neurotrack-ai-hcmg.vercel.app/';

// 2026-08-18: Firebase Hosting is now configured for Doctor_Dashboard
// (Doctor_Dashboard/firebase.json + .firebaserc, same neuromorph-624c0
// project as everything else) -- the URL below is Firebase Hosting's
// standard, deterministic default-site address for this project ID, so it
// can be filled in ahead of the actual deploy. DoctorHomeSection.jsx shows
// an honest "not deployed yet" state whenever this is empty (it's real
// content now, not a placeholder) -- but the link will 404 until the
// deploy step in DOCTOR_DASHBOARD_DEPLOY.md is actually run.
export const DOCTOR_DASHBOARD_URL = 'https://neuromorph-624c0.web.app';
