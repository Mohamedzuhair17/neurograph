import LineChart from '../charts/LineChart.jsx';

// 2026-08-18: this used to be one long section bundling six different real
// views (trend charts, domain breakdown, activity heatmap, clinical
// insights, and the report download) under a single "My Progress" nav
// item -- part of why the nav only had 5 items total. Domain Breakdown,
// Activity, Clinical Insights, and the report download each got their own
// top-level section (see DomainsSection.jsx / ActivitySection.jsx /
// InsightsSection.jsx / ReportsSection.jsx) using this exact same real
// data, nothing fabricated -- this section now covers just the trend
// charts (weekly, monthly, daily momentum) its name actually promises.
export default function ProgressSection({ self }) {
  if (!self) return null;
  const { weeklyCognitiveScoreHistory, monthlyCognitiveScoreHistory, momentumHistory, streak, longestStreak } = self;

  return (
    <div className="nmpa-section">
      <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '0ms' }}>
        <h2 className="nmpa-card__title">My Progress</h2>
        <p className="nmpa-muted">Your cognitive score trend over time, weekly and monthly.</p>
      </section>

      <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '60ms' }}>
        <h3 className="nmpa-card__title">Weekly Cognitive Score</h3>
        <LineChart series={weeklyCognitiveScoreHistory} label="Weekly cognitive score over time" />
      </section>

      <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '120ms' }}>
        <h3 className="nmpa-card__title">Monthly Trend</h3>
        <LineChart series={monthlyCognitiveScoreHistory} label="Monthly cognitive score trend" />
      </section>

      <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '180ms' }}>
        <h3 className="nmpa-card__title">Daily Momentum Score (last {momentumHistory.length} days)</h3>
        <LineChart series={momentumHistory} label="Daily Momentum Score over time" />
        <p className="nmpa-muted">Current streak: {streak} days · Longest streak: {longestStreak} days.</p>
      </section>
    </div>
  );
}
