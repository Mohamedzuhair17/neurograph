import { doc, getDoc, setDoc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebaseConfig.js';

// ============================================================================
// BROWSER-ONLY. The caregiver counterpart to FirestoreUserService.js/
// FirestoreDoctorService.js -- same seam pattern, same createdAt/updatedAt
// serverTimestamp() convention. useCaregiverAuth.js is the only caller.
//
// Also owns the /inviteCodes/{code} collection -- the patient <-> caregiver
// pairing mechanism (see InviteCodeEngine.js for the pure code-generation
// logic). A code document is intentionally tiny and NOT queryable by
// listing (firestore.rules grants `get` by exact id only, never `list`), so
// a code can't be enumerated or guessed by scanning -- only looked up if
// you already have the exact code a patient shared with you.
// ============================================================================
function caregiverDocRef(uid) {
  return doc(db, 'caregivers', uid);
}

function inviteCodeDocRef(code) {
  return doc(db, 'inviteCodes', code);
}

export const FirestoreCaregiverService = {
  async getCaregiverProfile(uid) {
    const snap = await getDoc(caregiverDocRef(uid));
    return snap.exists() ? snap.data() : null;
  },

  async createCaregiverProfile(uid, profileDoc) {
    const withTimestamps = { ...profileDoc, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
    await setDoc(caregiverDocRef(uid), withTimestamps);
    return profileDoc;
  },

  async updateCaregiverProfile(uid, partialUpdate) {
    await updateDoc(caregiverDocRef(uid), { ...partialUpdate, updatedAt: serverTimestamp() });
  },

  // Called from the PATIENT's own account (see useAuth.js) when they
  // generate a code to share with a caregiver. `code` is already
  // real/unique-enough from InviteCodeEngine.generate() -- this just
  // persists it. Overwrites any previous code for this patient the moment
  // a new one is generated (setDoc on a NEW code doc, old one left orphaned
  // but harmless/unreadable-by-list -- acceptable for this scope; a real
  // "revoke old code" cleanup step would delete the prior doc too, a
  // reasonable future follow-up, not done here).
  async createInviteCode(code, patientUid, patientName) {
    await setDoc(inviteCodeDocRef(code), { patientUid, patientName: patientName || null, createdAt: serverTimestamp() });
  },

  // Returns { patientUid, patientName } or undefined if the code doesn't
  // exist -- never throws on a not-found code, since "the caregiver typed
  // it wrong" is an expected, normal case, not an error condition.
  async resolveInviteCode(code) {
    const snap = await getDoc(inviteCodeDocRef(code));
    return snap.exists() ? snap.data() : undefined;
  },

  async deleteInviteCode(code) {
    await deleteDoc(inviteCodeDocRef(code));
  },
};
