// The caregiver's daily check-in: 15 questions total about the PATIENT
// (recovery/improvement, day-to-day activities, mood/behaviour, safety) --
// never questions about the caregiver themselves. 10 are FIXED (asked every
// day, the stable core signal a doctor could trend over time) and 5 are
// picked, deterministically rotating, from a 20-question pool, so the
// check-in doesn't feel identical every single day while the important
// core stays consistent. Matches the direct spec: "need not change every
// question daily but atleast few questions can be changed on a daily
// basis."
//
// `type`: 'scale' (1-5, rendered as 5 buttons), 'yesno' (2 buttons), or
// 'text' (free-form, always optional regardless of `required`, since
// forcing a caregiver to write something every day is exactly the kind of
// punitive UX this whole project has avoided elsewhere -- see
// dailyTaskConfig.js's own "soft-mandatory" philosophy).
export const CAREGIVER_FIXED_QUESTIONS = [
  { id: 'overallWellbeing', type: 'scale', category: 'recovery', label: "Overall, how would you rate the patient's wellbeing today?", scaleLabels: ['Very poor', 'Poor', 'Okay', 'Good', 'Very good'] },
  { id: 'memoryLapses', type: 'yesno', category: 'recovery', label: 'Did you notice any new or unusual memory lapses today?' },
  { id: 'dailyActivities', type: 'scale', category: 'activities', label: 'How independently did they manage daily activities today (eating, dressing, moving around)?', scaleLabels: ['Needed full help', 'Needed a lot of help', 'Needed some help', 'Mostly independent', 'Fully independent'] },
  { id: 'moodToday', type: 'scale', category: 'mood', label: "How would you describe the patient's mood today?", scaleLabels: ['Very low', 'Low', 'Neutral', 'Good', 'Very positive'] },
  { id: 'sleepQuality', type: 'scale', category: 'activities', label: 'How was their sleep last night, as far as you know?', scaleLabels: ['Very poor', 'Poor', 'Okay', 'Good', 'Very good'] },
  { id: 'appetiteToday', type: 'scale', category: 'activities', label: 'How was their appetite today?', scaleLabels: ['Very poor', 'Poor', 'Okay', 'Good', 'Very good'] },
  { id: 'confusionEpisodes', type: 'yesno', category: 'recovery', label: 'Did they seem confused or disoriented at any point today?' },
  { id: 'medicationTaken', type: 'yesno', category: 'safety', label: 'Were they able to take their medication as scheduled today, if applicable?' },
  { id: 'socialEngagement', type: 'scale', category: 'mood', label: 'How engaged were they with conversation or social interaction today?', scaleLabels: ['Withdrawn', 'A little', 'Some', 'Engaged', 'Very engaged'] },
  { id: 'anyConcerns', type: 'text', category: 'recovery', label: "Any specific concerns or observations you'd like to note today? (optional)" },
];

export const CAREGIVER_ROTATING_POOL = [
  { id: 'physicalMobility', type: 'scale', category: 'activities', label: 'How was their physical mobility or balance today?', scaleLabels: ['Very poor', 'Poor', 'Okay', 'Good', 'Very good'] },
  { id: 'repeatedQuestions', type: 'yesno', category: 'recovery', label: 'Did they repeat the same question or story multiple times today?' },
  { id: 'recognizedFamiliarPeople', type: 'yesno', category: 'recovery', label: 'Did they recognize familiar people (family, regular visitors) today?' },
  { id: 'followedConversation', type: 'scale', category: 'mood', label: 'How well could they follow a conversation today?', scaleLabels: ['Not at all', 'A little', 'Somewhat', 'Well', 'Very well'] },
  { id: 'participatedInHobbies', type: 'yesno', category: 'activities', label: 'Did they engage in a hobby or activity they enjoy today?' },
  { id: 'irritabilityLevel', type: 'scale', category: 'mood', label: 'How irritable or agitated did they seem today?', scaleLabels: ['Not at all', 'A little', 'Somewhat', 'Quite a bit', 'Very much'] },
  { id: 'hygieneIndependence', type: 'scale', category: 'activities', label: 'How independently did they manage personal hygiene today?', scaleLabels: ['Needed full help', 'Needed a lot of help', 'Needed some help', 'Mostly independent', 'Fully independent'] },
  { id: 'wanderingOrDisorientation', type: 'yesno', category: 'safety', label: 'Did they wander or seem lost/disoriented in a familiar place today?' },
  { id: 'comparedToLastWeek', type: 'scale', category: 'recovery', label: 'Compared to last week, how would you rate their overall functioning today?', scaleLabels: ['Much worse', 'A little worse', 'About the same', 'A little better', 'Much better'] },
  { id: 'restfulnessDuringDay', type: 'scale', category: 'mood', label: 'How restful or calm did they seem during the day?', scaleLabels: ['Very restless', 'Restless', 'Okay', 'Calm', 'Very calm'] },
  { id: 'appetiteChanges', type: 'yesno', category: 'activities', label: 'Did you notice any unusual change in their eating habits today?' },
  { id: 'balanceOrFalls', type: 'yesno', category: 'safety', label: 'Did they stumble, lose balance, or have a near-fall today?' },
  { id: 'communicationClarity', type: 'scale', category: 'recovery', label: 'How clearly were they able to express themselves today?', scaleLabels: ['Very unclear', 'Unclear', 'Okay', 'Clear', 'Very clear'] },
  { id: 'anxietySigns', type: 'yesno', category: 'mood', label: 'Did they show any signs of unusual anxiety or worry today?' },
  { id: 'independentDecisionMaking', type: 'scale', category: 'activities', label: 'How well did they make small everyday decisions on their own today (what to wear, what to eat)?', scaleLabels: ['Not at all', 'Rarely', 'Sometimes', 'Mostly', 'Fully'] },
  { id: 'timeOrPlaceConfusion', type: 'yesno', category: 'safety', label: 'Did they seem unsure about the day, time, or where they were at any point today?' },
  { id: 'energyLevel', type: 'scale', category: 'activities', label: "How was the patient's energy level today?", scaleLabels: ['Very low', 'Low', 'Moderate', 'Good', 'Very good'] },
  { id: 'newSymptomsNoticed', type: 'yesno', category: 'safety', label: 'Did you notice any new physical symptom today (pain, dizziness, tremor, etc.)?' },
  { id: 'positiveMomentToday', type: 'text', category: 'mood', label: "Any positive moment from today you'd like to share? (optional)" },
  { id: 'compareToYesterday', type: 'scale', category: 'recovery', label: 'Compared to yesterday specifically, how would you rate today?', scaleLabels: ['Much worse', 'A little worse', 'About the same', 'A little better', 'Much better'] },
];

export const CAREGIVER_ROTATING_COUNT = 5;
export const CAREGIVER_DAILY_TOTAL = CAREGIVER_FIXED_QUESTIONS.length + CAREGIVER_ROTATING_COUNT;
