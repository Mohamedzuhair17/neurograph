import ThemeToggle from '../common/ThemeToggle.jsx';
import { DOCTOR_DASHBOARD_URL } from '../../config/externalLinksConfig.js';
import { DOCTOR_MOCK_PATIENTS } from '../../data/doctorMockPatients.js';
import { bandFromScore } from '../../config/scoringBands.js';

function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase();
}

function greeting(now = new Date()) {
  const hour = now.getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

// The doctor counterpart to HomeSection.jsx -- a single-screen shell
// (doctors don't get the patient's 5-tab sidenav; today the only thing to
// do here is read your profile, open the clinical assistant, or hand off
// to the fuller Doctor Dashboard) rather than generalizing DashboardShell's
// hardcoded SECTIONS just for a one-section role.
//
// 2026-08-21: same card-entrance treatment as patient Home (nmpa-anim-fade-up,
// 60ms stagger top to bottom) -- motion/design pass only, not i18n (this
// screen stays English-only for now, same as the rest of the doctor/
// caregiver chrome per OVERNIGHT_PLAN.md's checklist).
export default function DoctorHomeSection({ doctor, onLogout, theme, onToggleTheme, onOpenChat }) {
  if (!doctor) return null;
  const firstName = doctor.name?.split(' ')[1] || doctor.name?.split(' ')[0] || 'Doctor';
  const profile = doctor.professionalProfile;

  return (
    <div className="nmpa-shell">
      <header className="nmpa-topbar">
        <span className="nmpa-brand-mark">NEUROMORPH</span>
        <div className="nmpa-topbar__user">
          {theme && onToggleTheme && <ThemeToggle theme={theme} onToggle={onToggleTheme} size="sm" />}
          <span className="nmpa-avatar" aria-hidden="true">{initials(doctor.name)}</span>
          <span>{doctor.name}</span>
          <button type="button" className="nmpa-link" onClick={onLogout}>Log out</button>
        </div>
      </header>

      <main className="nmpa-shell__main nmpa-home">
        <div className="nmpa-home__greeting">
          <p className="nmpa-eyebrow">Doctor Portal</p>
          <h1 className="nmpa-home__title">{greeting()}, Dr. {firstName}.</h1>
        </div>

        <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '0ms' }}>
          <h2 className="nmpa-card__title">Your professional profile</h2>
          {profile ? (
            <ul className="nmpa-checklist">
              <li className="nmpa-checklist__item">
                <span><span className="nmpa-checklist__label">Specialty</span><span className="nmpa-muted nmpa-muted--sm"> {profile.specialty === 'Other' ? profile.specialtyOther : profile.specialty}</span></span>
              </li>
              <li className="nmpa-checklist__item">
                <span><span className="nmpa-checklist__label">Years in practice</span><span className="nmpa-muted nmpa-muted--sm"> {profile.yearsOfPractice}</span></span>
              </li>
              <li className="nmpa-checklist__item">
                <span><span className="nmpa-checklist__label">Practice setting</span><span className="nmpa-muted nmpa-muted--sm"> {profile.practiceSetting === 'Other' ? profile.practiceSettingOther : profile.practiceSetting}</span></span>
              </li>
            </ul>
          ) : (
            <p className="nmpa-muted">No professional profile on file yet.</p>
          )}
        </section>

        <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '60ms' }}>
          <h2 className="nmpa-card__title">Ask the clinical assistant</h2>
          <p className="nmpa-muted">
            Morphy for Clinicians can explain scoring, task and domain methodology, or summarize a patient by name --
            try asking it to "summarize Eleanor Whitfield" for a quick summary you can turn into a PDF.
          </p>
          <button type="button" className="nmpa-button nmpa-button--primary" onClick={onOpenChat}>Open Morphy for Clinicians</button>
        </section>

        <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '120ms' }}>
          <h2 className="nmpa-card__title">Sample patient roster</h2>
          <p className="nmpa-muted nmpa-muted--sm">
            Demo data for this build -- ask the assistant about any of these by name.
          </p>
          <ul className="nmpa-checklist">
            {DOCTOR_MOCK_PATIENTS.map((p) => {
              const latest = p.sessions[p.sessions.length - 1];
              return (
                <li key={p.patientId} className="nmpa-checklist__item">
                  <span>
                    <span className="nmpa-checklist__label">{p.name}</span>
                    <span className="nmpa-muted nmpa-muted--sm"> {p.patientId} -- latest {latest.overallRawScore} ({bandFromScore(latest.overallRawScore)})</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '180ms' }}>
          <h2 className="nmpa-card__title">Full Doctor Dashboard</h2>
          {DOCTOR_DASHBOARD_URL ? (
            <a className="nmpa-button nmpa-button--secondary" href={DOCTOR_DASHBOARD_URL} target="_blank" rel="noreferrer">
              Go to Doctor Dashboard
            </a>
          ) : (
            <p className="nmpa-muted nmpa-muted--sm">
              The full Doctor Dashboard (alert triage, complete session history, caregiver notes) isn't deployed with a public link yet -- it currently runs as its own separate app in this project.
            </p>
          )}
        </section>
      </main>
    </div>
  );
}
