import { useState, useCallback, useEffect, useRef } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
  signOut,
} from 'firebase/auth';
import { AuthEngine } from '../engines/AuthEngine.js';
import { MOCK_DOCTOR } from '../data/mockDoctor.js';
import { auth, googleProvider, facebookProvider, isFirebaseConfigured } from '../config/firebaseConfig.js';
import { FirestoreDoctorService } from '../services/FirestoreDoctorService.js';

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// 2026-08-17: the doctor counterpart to useAuth.js -- separate hook (not a
// role flag bolted onto useAuth) since a doctor record and a patient record
// are genuinely different shapes (see mockDoctor.js), same reasoning
// Doctor_Dashboard already used for its own useDoctorAuth.js/
// DoctorAuthEngine.js.
//
// 2026-08-18 UPDATE -- real Firebase accounts. Wired to the same
// signInWithEmailAndPassword / signInWithPopup / Firestore pattern
// useAuth.js already uses for patients, now that a real Firebase project
// exists (mirrors that same FALLBACK rule too: everything below falls back
// to the original mock behavior when isFirebaseConfigured is false).
//
// REAL LIMITATION (disclosed, not hidden): patients and doctors are stored
// as SEPARATE Firestore documents (/users/{uid} vs /doctors/{uid}), but
// both roles authenticate against the SAME underlying Firebase Auth user
// pool -- Firebase's JS SDK doesn't cleanly support two independent,
// concurrently-signed-in sessions in one browser tab without a second named
// Auth instance (real added complexity this build doesn't need yet). In
// practice this only matters if literally the same email+password is used
// to sign up as both a patient and a doctor -- an edge case, not the normal
// "pick a role, then log in" flow this app's role-gate screen enforces.
//
// ACCESS-APPROVAL SCOPE NOTE (disclosed, not hidden): the real
// Doctor_Dashboard app gates patient-data access behind admin approval
// (DoctorAccessPendingScreen.jsx). No real admin-approval backend exists in
// this delivery, so a freshly created REAL doctor account is auto-approved
// on signup rather than left permanently stuck pending an approval nobody
// can grant. Before this app handles real patients, replace this with a
// real admin review step (e.g. an isAdmin-gated screen that flips
// accessApproved in Firestore).
//
// 2026-08-19 BUG FIX: a doctor account created BEFORE this auto-approve
// default existed (or created any other way with accessApproved left
// false/missing) would load that same stale Firestore document on every
// future sign-in -- including via Google/Facebook -- and get permanently
// stuck on DoctorAccessPendingScreen with no way to self-recover, since
// nothing ever re-checked or corrected that field afterward. Since there is
// still no real admin-approval backend, the honest, permitted-for-now fix
// is to self-heal: if an existing doctor profile is ever found with
// accessApproved !== true, flip it to true right here, the same value
// every fresh signup already gets. This is scoped to app_page's own doctor
// login only -- Doctor_Dashboard's separate accessApproved gate (which
// actually exposes real patient records, a higher-stakes surface) is left
// untouched.
export function useDoctorAuth() {
  const [view, setView] = useState('login'); // 'login' | 'signup'
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentDoctor, setCurrentDoctor] = useState(null);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCheckingSession, setIsCheckingSession] = useState(isFirebaseConfigured);
  // 2026-08-21: same consent-plumbing pattern as useAuth.js -- see that
  // file's comment on the equivalent ref.
  const pendingConsentRef = useRef(null);

  useEffect(() => {
    if (!isFirebaseConfigured) {
      setIsCheckingSession(false);
      return undefined;
    }
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (!firebaseUser) {
        setCurrentDoctor(null);
        setIsAuthenticated(false);
        setIsCheckingSession(false);
        return;
      }
      try {
        let profile = await FirestoreDoctorService.getDoctorProfile(firebaseUser.uid);
        if (!profile) {
          // No /doctors/{uid} record yet for this uid -- either their very
          // first Google/Facebook sign-in, or (see the shared-auth-pool
          // note above) a uid that only ever signed up as a patient. Either
          // way, create a real, honest, never-fabricated doctor record now.
          const consentGiven = pendingConsentRef.current === true;
          pendingConsentRef.current = null;
          profile = {
            name: firebaseUser.displayName || 'there',
            email: firebaseUser.email,
            role: 'doctor',
            doctorId: `NMD-${firebaseUser.uid.slice(0, 6).toUpperCase()}`,
            onboardingComplete: false,
            professionalProfile: null,
            accessApproved: true, // see ACCESS-APPROVAL SCOPE NOTE above
            authProvider: firebaseUser.providerData?.[0]?.providerId || 'password',
            privacyConsentAcceptedAt: consentGiven ? new Date().toISOString() : null,
          };
          await FirestoreDoctorService.createDoctorProfile(firebaseUser.uid, profile);
        } else if (profile.accessApproved !== true) {
          // Self-heal a previously-stuck account -- see the 2026-08-19 BUG
          // FIX note above.
          await FirestoreDoctorService.updateDoctorProfile(firebaseUser.uid, { accessApproved: true });
          profile = { ...profile, accessApproved: true };
        }
        setCurrentDoctor({ ...profile, uid: firebaseUser.uid });
        setIsAuthenticated(true);
      } finally {
        setIsCheckingSession(false);
      }
    });
    return unsubscribe;
  }, []);

  const login = useCallback(async ({ email, password }) => {
    const result = AuthEngine.validateLogin({ email, password });
    setErrors(result.errors);
    if (!result.valid) return false;

    if (!isFirebaseConfigured) {
      setIsSubmitting(true);
      await wait(500);
      setCurrentDoctor(MOCK_DOCTOR);
      setIsAuthenticated(true);
      setIsSubmitting(false);
      return true;
    }

    setIsSubmitting(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return true;
    } catch (err) {
      setErrors(AuthEngine.mapFirebaseError(err.code));
      return false;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const signup = useCallback(async ({ name, email, password, confirmPassword, consentGiven = false }) => {
    const result = AuthEngine.validateSignup({ name, email, password, confirmPassword });
    setErrors(result.errors);
    if (!result.valid) return false;

    if (!isFirebaseConfigured) {
      setIsSubmitting(true);
      await wait(500);
      setCurrentDoctor({
        ...MOCK_DOCTOR,
        name,
        email,
        onboardingComplete: false,
        professionalProfile: null,
        accessApproved: false,
      });
      setIsAuthenticated(true);
      setIsSubmitting(false);
      return true;
    }

    setIsSubmitting(true);
    try {
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(credential.user, { displayName: name });
      const profile = {
        name,
        email,
        role: 'doctor',
        doctorId: `NMD-${credential.user.uid.slice(0, 6).toUpperCase()}`,
        onboardingComplete: false,
        professionalProfile: null,
        accessApproved: true, // see ACCESS-APPROVAL SCOPE NOTE above
        authProvider: 'password',
        privacyConsentAcceptedAt: consentGiven ? new Date().toISOString() : null,
      };
      await FirestoreDoctorService.createDoctorProfile(credential.user.uid, profile);
      setCurrentDoctor({ ...profile, uid: credential.user.uid });
      setIsAuthenticated(true);
      return true;
    } catch (err) {
      setErrors(AuthEngine.mapFirebaseError(err.code));
      return false;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const loginWithProvider = useCallback(async (provider, consentGiven = false) => {
    if (!isFirebaseConfigured) return false;
    setErrors({});
    setIsSubmitting(true);
    pendingConsentRef.current = consentGiven;
    try {
      const authProvider = provider === 'facebook' ? facebookProvider : googleProvider;
      await signInWithPopup(auth, authProvider);
      return true;
    } catch (err) {
      pendingConsentRef.current = null;
      setErrors(AuthEngine.mapFirebaseError(err.code));
      return false;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const logout = useCallback(async () => {
    if (isFirebaseConfigured) {
      await signOut(auth);
    }
    setIsAuthenticated(false);
    setCurrentDoctor(null);
    setView('login');
    setErrors({});
  }, []);

  const completeOnboarding = useCallback((professionalProfile) => {
    setCurrentDoctor((prev) => {
      if (!prev) return prev;
      const updated = { ...prev, professionalProfile, onboardingComplete: true };
      if (isFirebaseConfigured && prev.uid) {
        FirestoreDoctorService.updateDoctorProfile(prev.uid, { professionalProfile, onboardingComplete: true });
      }
      return updated;
    });
  }, []);

  return {
    view,
    setView,
    isAuthenticated,
    currentDoctor,
    errors,
    isSubmitting,
    isCheckingSession,
    login,
    signup,
    loginWithProvider,
    logout,
    completeOnboarding,
  };
}
