import { CAREGIVER_FIXED_QUESTIONS, CAREGIVER_ROTATING_POOL, CAREGIVER_ROTATING_COUNT } from '../config/caregiverDailyConfig.js';

const MS_PER_DAY = 24 * 60 * 60 * 1000;

function epochDayNumber(dateIso) {
  return Math.floor(new Date(`${dateIso}T00:00:00Z`).getTime() / MS_PER_DAY);
}

// Deterministic (never Math.random) day-to-question-set picker, same
// philosophy as DailyGameRotationEngine.js: the same date always resolves
// to the same 5 rotating questions, so reloading mid-day never changes
// what's asked, and this stays trivially unit-testable. Rotates the whole
// pool by the day count so the 5 shown are always distinct and the full
// pool cycles through evenly (20 questions / 5 per day = a 4-day cycle).
export const CaregiverDailyRotationEngine = {
  rotatingQuestionsFor(dateIso) {
    if (!dateIso) return [];
    const pool = CAREGIVER_ROTATING_POOL;
    const offset = epochDayNumber(dateIso) % pool.length;
    const rotated = [...pool.slice(offset), ...pool.slice(0, offset)];
    return rotated.slice(0, CAREGIVER_ROTATING_COUNT);
  },

  // The full 15-question set for a given date -- fixed 10 first, then
  // today's 5 rotating picks, in that order (matches how the check-in UI
  // renders them).
  questionsFor(dateIso) {
    return [...CAREGIVER_FIXED_QUESTIONS, ...this.rotatingQuestionsFor(dateIso)];
  },
};
