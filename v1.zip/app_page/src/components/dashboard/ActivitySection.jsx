import ActivityHeatmap from '../charts/ActivityHeatmap.jsx';

// Split out of the old, over-bundled ProgressSection.jsx (2026-08-18) --
// same real ActivityHeatmap and data, just its own top-level section.
//
// 2026-08-21: card entrance (nmpa-anim-fade-up) -- deliberately NOT a
// per-cell heatmap animation (84 cells staggering in would fight the
// "restraint fitting Samsung Health's actual feel" guidance in
// OVERNIGHT_PLAN.md, not honor it).
export default function ActivitySection({ self }) {
  if (!self) return null;
  const { activityHeatmap } = self;

  return (
    <div className="nmpa-section">
      <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '0ms' }}>
        <p className="nmpa-eyebrow">Activity</p>
        <h2 className="nmpa-card__title">Daily Set activity (last 12 weeks)</h2>
        <p className="nmpa-muted">Every day you completed part or all of your Daily Set.</p>
        <ActivityHeatmap heatmap={activityHeatmap} />
      </section>
    </div>
  );
}
