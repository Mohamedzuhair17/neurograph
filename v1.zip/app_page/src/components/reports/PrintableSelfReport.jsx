// Print-only layout for the "Download Monthly Report" workflow -- same
// pattern as the Doctor Dashboard's PrintableReport.jsx: hidden on-screen
// via print.css, shown only when the browser's print dialog opens, and the
// user's own "Save as PDF" destination produces the actual file.
export default function PrintableSelfReport({ self }) {
  if (!self) return null;
  const { name, patientId, age, streak, longestStreak, weeklyCognitiveScoreHistory, momentumHistory, weeklyAssessment } = self;

  return (
    <div className="nmpa-print-report nmpa-print-only">
      <h1>NEUROMORPH Monthly Progress Report</h1>
      <p className="nmpa-print-disclaimer">
        Early cognitive screening summary. Not a diagnostic report. Findings require clinical correlation.
      </p>

      <h2>Patient</h2>
      <table className="nmpa-print-table">
        <tbody>
          <tr><td>Name</td><td>{name}</td></tr>
          <tr><td>Age</td><td>{age}</td></tr>
          <tr><td>Patient ID</td><td>{patientId}</td></tr>
          <tr><td>Current Streak</td><td>{streak} days (longest: {longestStreak})</td></tr>
          <tr><td>This Week's Assessment</td><td>{weeklyAssessment.status}</td></tr>
        </tbody>
      </table>

      <h2>Weekly Cognitive Score History</h2>
      <table className="nmpa-print-table">
        <thead><tr><th>Date</th><th>Score</th></tr></thead>
        <tbody>
          {weeklyCognitiveScoreHistory.map((h) => (
            <tr key={h.date}><td>{h.date}</td><td>{h.score}</td></tr>
          ))}
        </tbody>
      </table>

      <h2>Daily Momentum Score History</h2>
      <table className="nmpa-print-table">
        <thead><tr><th>Date</th><th>Momentum Score</th><th>Completion %</th></tr></thead>
        <tbody>
          {momentumHistory.map((h) => (
            <tr key={h.date}><td>{h.date}</td><td>{h.score}</td><td>{h.completionPct}%</td></tr>
          ))}
        </tbody>
      </table>

      <p className="nmpa-print-disclaimer">
        NEUROMORPH is an early cognitive screening tool, not a diagnostic instrument. This report summarizes task
        performance and engagement only and does not constitute a diagnosis of dementia or any other condition.
      </p>
    </div>
  );
}
