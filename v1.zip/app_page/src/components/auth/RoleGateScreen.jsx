import ThemeToggle from '../common/ThemeToggle.jsx';
import RoleGateBackdrop from './RoleGateBackdrop.jsx';
import { DEFAULT_LANGUAGE } from '../../config/i18nConfig.js';
import { t } from '../../i18n/strings/roleGate.js';

// 2026-08-17: the very first screen now, before either login form --
// previously app_page only ever showed the patient login. A doctor now has
// a real front door here too (see useDoctorAuth.js / DoctorLoginScreen.jsx),
// separate from the existing, fully separate Doctor_Dashboard app (which
// still owns the actual patient-list/report-review UI -- this screen only
// decides which LOGIN a person sees, it doesn't merge the two apps).
//
// 2026-08-18: originally showed a static reference photo
// (role-gate-cover.png) as the background, with RoleGateBackdrop (the
// hand-built animated SVG) only as an onError fallback.
//
// 2026-08-22 (VR request): switched to ALWAYS using RoleGateBackdrop, for
// two real reasons, not just "animation is nicer":
//   1. The static photo's callout labels ("Visuospatial", "Insights") are
//      generic reference-image text, not this app's real 6 cognitive
//      domains -- RoleGateBackdrop already uses the real ones (see its own
//      header comment). The photo was drifting out of sync with the actual
//      product.
//   2. The photo sat behind a hardcoded-dark scrim
//      (`.nmpa-rolegate__cover-scrim`, now removed) while the card text on
//      top of it used the theme-reactive `--nmpa-auth-brand-ink` variable.
//      In light theme that flips card text to a dark navy that's very low
//      contrast against the still-always-dark photo -- the screen looked
//      "completely different" (and badly broken) after a theme toggle.
//      RoleGateBackdrop's own background/ink both come from the same
//      theme-reactive `--nmpa-auth-brand-*` variables, so it never
//      disagrees with itself again.
export default function RoleGateScreen({ onSelectRole, theme, onToggleTheme, language = DEFAULT_LANGUAGE }) {
  return (
    <div className="nmpa-rolegate">
      <RoleGateBackdrop />
      <div className="nmpa-auth__theme-toggle-slot">
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
      </div>

      <div className="nmpa-rolegate__content">
        <p className="nmpa-brand-mark nmpa-brand-mark--lg nmpa-rolegate__brand">NEUROMORPH</p>
        <p className="nmpa-rolegate__lede">{t(language, 'lede')}</p>

        <div className="nmpa-rolegate__cards">
          <button type="button" className="nmpa-rolegate__card" onClick={() => onSelectRole('patient')}>
            <span className="nmpa-rolegate__card-title">{t(language, 'patientTitle')}</span>
            <span className="nmpa-rolegate__card-sub">{t(language, 'patientSub')}</span>
          </button>

          {/* 2026-08-21: reordered to Patient / Caregiver / Doctor per VR's
              request -- caregiver sits in the middle now, not last. Purely
              a display-order change (onSelectRole('caregiver'/'doctor')
              values are unchanged, so nothing downstream in App.jsx needed
              touching). */}
          <button type="button" className="nmpa-rolegate__card" onClick={() => onSelectRole('caregiver')}>
            <span className="nmpa-rolegate__card-title">{t(language, 'caregiverTitle')}</span>
            <span className="nmpa-rolegate__card-sub">{t(language, 'caregiverSub')}</span>
          </button>

          <button type="button" className="nmpa-rolegate__card" onClick={() => onSelectRole('doctor')}>
            <span className="nmpa-rolegate__card-title">{t(language, 'doctorTitle')}</span>
            <span className="nmpa-rolegate__card-sub">{t(language, 'doctorSub')}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
