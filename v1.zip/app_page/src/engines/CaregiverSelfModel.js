import { CaregiverDailyTaskEngine } from './CaregiverDailyTaskEngine.js';
import { CaregiverStreakEngine } from './CaregiverStreakEngine.js';

const toIsoDate = (date) => date.toISOString().slice(0, 10);

// The caregiver counterpart to SelfModel.js -- the single assembler
// CaregiverHomeSection reads from. Components never compute checklist
// status or streak themselves.
export const CaregiverSelfModel = {
  build(caregiver, now = new Date()) {
    const todayIso = caregiver?.today?.date || toIsoDate(now);
    const completion = caregiver?.today?.completion || {};

    const checklist = CaregiverDailyTaskEngine.buildChecklist(todayIso, completion);
    const { done, total } = CaregiverDailyTaskEngine.completionCount(todayIso, completion);
    const fullyComplete = CaregiverDailyTaskEngine.isFullyComplete(todayIso, completion);

    const streak = CaregiverStreakEngine.currentStreak(caregiver?.dailyHistory || []);
    const longestStreak = CaregiverStreakEngine.longestStreak(caregiver?.dailyHistory || []);

    return {
      name: caregiver?.name,
      linkedPatientUid: caregiver?.linkedPatientUid || null,
      linkedPatientName: caregiver?.linkedPatientName || null,
      isLinked: Boolean(caregiver?.linkedPatientUid),
      today: {
        date: todayIso,
        checklist,
        completedCount: done,
        totalCount: total,
        fullyComplete,
      },
      streak,
      longestStreak,
    };
  },
};
