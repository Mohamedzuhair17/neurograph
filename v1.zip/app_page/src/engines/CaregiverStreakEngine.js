import { CaregiverDailyTaskEngine } from './CaregiverDailyTaskEngine.js';

// The caregiver counterpart to StreakEngine.js -- same "consecutive days,
// counting back from the most recent, today excluded" logic, but calls
// CaregiverDailyTaskEngine (date-aware, since the question set rotates)
// instead of DailyTaskEngine. No designated rest day here on purpose --
// that concept (StreakEngine's restDayOfWeek) is specific to the patient's
// game-based daily mission; a caregiver's daily observation of the patient
// doesn't have an equivalent "day off" built in, since the patient's status
// doesn't pause just because their own games have a rest day.
export const CaregiverStreakEngine = {
  currentStreak(dailyHistory = []) {
    const sorted = [...dailyHistory].sort((a, b) => new Date(a.date) - new Date(b.date));
    let streak = 0;
    for (let i = sorted.length - 1; i >= 0; i--) {
      if (CaregiverDailyTaskEngine.isFullyComplete(sorted[i].date, sorted[i].completion)) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  },

  longestStreak(dailyHistory = []) {
    const sorted = [...dailyHistory].sort((a, b) => new Date(a.date) - new Date(b.date));
    let longest = 0;
    let running = 0;
    for (const day of sorted) {
      const isFull = CaregiverDailyTaskEngine.isFullyComplete(day.date, day.completion);
      running = isFull ? running + 1 : 0;
      longest = Math.max(longest, running);
    }
    return longest;
  },
};
