export default function MorphySection({ onOpenChat }) {
  return (
    <div className="nmpa-section">
      <section className="nmpa-card nmpa-home__hero">
        <div>
          <h2 className="nmpa-card__title">Chat with Morphy</h2>
          <p className="nmpa-muted">
            Morphy can answer questions about the app, walk you through any game, explain your reports, help with
            errors, or take a report PDF and explain it in plain language. Morphy is also available from the chat
            bubble in the corner of every page.
          </p>
          <button type="button" className="nmpa-button nmpa-button--primary" onClick={onOpenChat}>Open Chat</button>
        </div>
      </section>
    </div>
  );
}
