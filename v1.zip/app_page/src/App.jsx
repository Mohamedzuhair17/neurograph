import { useState, useCallback, useEffect, useRef } from 'react';
import { useAuth } from './hooks/useAuth.js';
import { useSelf } from './hooks/useSelf.js';
import { useMorphyChat } from './hooks/useMorphyChat.js';
import { useDetectionAssessment } from './hooks/useDetectionAssessment.js';
import { useOnboarding } from './hooks/useOnboarding.js';
import { useTheme } from './hooks/useTheme.js';
import { useLanguage } from './hooks/useLanguage.js';
import { useDoctorAuth } from './hooks/useDoctorAuth.js';
import { useDoctorChat } from './hooks/useDoctorChat.js';
import { useCaregiverAuth } from './hooks/useCaregiverAuth.js';
import { useCaregiverChat } from './hooks/useCaregiverChat.js';
import { CaregiverSelfModel } from './engines/CaregiverSelfModel.js';
import { DOCTOR_ONBOARDING_STEPS } from './config/doctorOnboardingConfig.js';
import { CAREGIVER_ONBOARDING_STEPS } from './config/caregiverOnboardingConfig.js';

import LoginScreen from './components/auth/LoginScreen.jsx';
import SignupScreen from './components/auth/SignupScreen.jsx';
import OnboardingStep from './components/onboarding/OnboardingStep.jsx';
import OnboardingComplete from './components/onboarding/OnboardingComplete.jsx';
import DashboardShell from './components/dashboard/DashboardShell.jsx';
import HomeSection from './components/dashboard/HomeSection.jsx';
import AssessmentSection from './components/dashboard/AssessmentSection.jsx';
import GamesSection from './components/dashboard/GamesSection.jsx';
import ProgressSection from './components/dashboard/ProgressSection.jsx';
import DomainsSection from './components/dashboard/DomainsSection.jsx';
import ActivitySection from './components/dashboard/ActivitySection.jsx';
import InsightsSection from './components/dashboard/InsightsSection.jsx';
import ReportsSection from './components/dashboard/ReportsSection.jsx';
import MorphySection from './components/dashboard/MorphySection.jsx';
import PrintableSelfReport from './components/reports/PrintableSelfReport.jsx';
import ChatBubbleButton from './components/chat/ChatBubbleButton.jsx';
import ChatPanel from './components/chat/ChatPanel.jsx';
import RoleGateScreen from './components/auth/RoleGateScreen.jsx';
import DoctorLoginScreen from './components/doctor/DoctorLoginScreen.jsx';
import DoctorSignupScreen from './components/doctor/DoctorSignupScreen.jsx';
import DoctorAccessPendingScreen from './components/doctor/DoctorAccessPendingScreen.jsx';
import DoctorHomeSection from './components/doctor/DoctorHomeSection.jsx';
import PrintableDoctorPatientReport from './components/reports/PrintableDoctorPatientReport.jsx';
import DoctorChatBubbleButton from './components/doctor/DoctorChatBubbleButton.jsx';
import DoctorChatPanel from './components/doctor/DoctorChatPanel.jsx';
import CaregiverLoginScreen from './components/caregiver/CaregiverLoginScreen.jsx';
import CaregiverSignupScreen from './components/caregiver/CaregiverSignupScreen.jsx';
import CaregiverLinkPatientScreen from './components/caregiver/CaregiverLinkPatientScreen.jsx';
import CaregiverHomeSection from './components/caregiver/CaregiverHomeSection.jsx';
import CaregiverChatBubbleButton from './components/caregiver/CaregiverChatBubbleButton.jsx';
import CaregiverChatPanel from './components/caregiver/CaregiverChatPanel.jsx';
import InstallAppPrompt from './components/common/InstallAppPrompt.jsx';

// Single top-level wiring point, same shape as the Doctor Dashboard's
// App.jsx and AI_ChatBot's App.jsx: one `useMorphyChat()` instance shared
// between the always-present corner bubble and the dedicated "Chat with
// Morphy" section's "Open Chat" button, so both open the SAME conversation.
export default function App() {
  const auth = useAuth();
  const self = useSelf(auth.currentUser);
  const assessment = useDetectionAssessment();
  const onboarding = useOnboarding();
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage } = useLanguage();
  // 2026-08-18: language is threaded into both chat hooks now, so Morphy
  // (patient and doctor) replies in whatever language is selected app-wide
  // -- see LanguageEngine.promptInstruction's comment for exactly how.
  const chat = useMorphyChat(assessment.phase, language);
  const [activeSection, setActiveSection] = useState('home');
  const hasRecordedThisCompletion = useRef(false);

  // 2026-08-17: the doctor front door -- role is chosen once, before either
  // login form, via RoleGateScreen. `null` means "not chosen yet" (show the
  // role gate); everything below this is a completely separate hook stack
  // from the patient flow above, mirroring how Doctor_Dashboard is a
  // separate app rather than a role flag bolted onto useAuth.
  const [role, setRole] = useState(null);
  const doctorAuth = useDoctorAuth();
  const doctorOnboarding = useOnboarding(DOCTOR_ONBOARDING_STEPS);
  const doctorChat = useDoctorChat(language);

  // 2026-08-19: third role, same "completely separate hook stack" pattern
  // as the doctor branch above -- see useCaregiverAuth.js.
  const caregiverAuth = useCaregiverAuth();
  const caregiverOnboarding = useOnboarding(CAREGIVER_ONBOARDING_STEPS);
  const caregiverChat = useCaregiverChat(language);
  const caregiverSelf = caregiverAuth.currentCaregiver ? CaregiverSelfModel.build(caregiverAuth.currentCaregiver) : null;

  const handlePrint = useCallback(() => window.print(), []);
  const handleLogout = useCallback(() => {
    auth.logout();
    onboarding.reset();
    setRole(null);
  }, [auth, onboarding]);

  const handleDoctorLogout = useCallback(() => {
    doctorAuth.logout();
    doctorOnboarding.reset();
    doctorChat.restart();
    setRole(null);
  }, [doctorAuth, doctorOnboarding, doctorChat]);

  const handleCaregiverLogout = useCallback(() => {
    caregiverAuth.logout();
    caregiverOnboarding.reset();
    caregiverChat.restart();
    setRole(null);
  }, [caregiverAuth, caregiverOnboarding, caregiverChat]);

  // The doctor chat's "generate a PDF for <patient>" flow sets
  // patientToPrint; this is the one place that actually opens the browser
  // print dialog, same "hook decides, App triggers the browser API" split
  // as handlePrint above. Cleared right after so re-asking for the same
  // patient still re-triggers a fresh print.
  useEffect(() => {
    if (doctorChat.patientToPrint) {
      const t = setTimeout(() => {
        window.print();
        doctorChat.clearPrintRequest();
      }, 50);
      return () => clearTimeout(t);
    }
  }, [doctorChat.patientToPrint, doctorChat.clearPrintRequest]);

  // The moment the assessment finishes, patch the in-memory record so
  // "this week's test: completed" shows immediately everywhere that reads
  // self.weeklyAssessment/weeklyCognitiveScoreHistory (Home, this section,
  // Progress) -- session-only, no backend yet, but real enough that the
  // app never re-invites a same-week retake right after finishing one.
  useEffect(() => {
    if (assessment.phase === 'complete' && assessment.session && !hasRecordedThisCompletion.current) {
      hasRecordedThisCompletion.current = true;
      auth.recordCompletedAssessment(assessment.session);
    }
    if (assessment.phase !== 'complete') {
      hasRecordedThisCompletion.current = false;
    }
  }, [assessment.phase, assessment.session, auth.recordCompletedAssessment]);

  // Firebase resolves whether a session already exists asynchronously --
  // this brief window only ever happens right on page load, and only when
  // Firebase is actually configured (see useAuth.js). Without this guard,
  // an already-logged-in user would see a flash of the login screen every
  // time they reload the page.
  if (auth.isCheckingSession) {
    return (
      <div className="nmpa-session-loading" role="status" aria-live="polite">
        <p className="nmpa-brand-mark nmpa-brand-mark--lg">NEUROMORPH</p>
        <p className="nmpa-muted">Loading your session…</p>
      </div>
    );
  }

  // Role picker is the very first screen -- before either login form.
  if (role === null) {
    return <RoleGateScreen onSelectRole={setRole} theme={theme} onToggleTheme={toggleTheme} language={language} />;
  }

  if (role === 'doctor') {
    if (doctorAuth.isCheckingSession) {
      return (
        <div className="nmpa-session-loading" role="status" aria-live="polite">
          <p className="nmpa-brand-mark nmpa-brand-mark--lg">NEUROMORPH</p>
          <p className="nmpa-muted">Loading your session…</p>
        </div>
      );
    }
    if (!doctorAuth.isAuthenticated) {
      return doctorAuth.view === 'signup' ? (
        <DoctorSignupScreen
          onSignup={doctorAuth.signup}
          onSwitchToLogin={() => doctorAuth.setView('login')}
          onSocialAuth={doctorAuth.loginWithProvider}
          onBackToRoleGate={() => setRole(null)}
          errors={doctorAuth.errors}
          isSubmitting={doctorAuth.isSubmitting}
          theme={theme}
          onToggleTheme={toggleTheme}
          language={language}
          onChangeLanguage={setLanguage}
        />
      ) : (
        <DoctorLoginScreen
          onLogin={doctorAuth.login}
          onSwitchToSignup={() => doctorAuth.setView('signup')}
          onSocialAuth={doctorAuth.loginWithProvider}
          onBackToRoleGate={() => setRole(null)}
          errors={doctorAuth.errors}
          isSubmitting={doctorAuth.isSubmitting}
          theme={theme}
          onToggleTheme={toggleTheme}
          language={language}
          onChangeLanguage={setLanguage}
        />
      );
    }

    // Shown exactly once, right after a fresh doctor signup (never after a
    // login -- MOCK_DOCTOR defaults to onboardingComplete: true, same
    // pattern as the patient flow's MOCK_SELF vs. signup() override).
    if (doctorAuth.currentDoctor?.onboardingComplete === false) {
      if (doctorOnboarding.isComplete) {
        return (
          <OnboardingComplete
            wasSkipped={doctorOnboarding.wasSkipped}
            onContinue={() => doctorAuth.completeOnboarding(doctorOnboarding.profile)}
          />
        );
      }
      return (
        <OnboardingStep
          steps={DOCTOR_ONBOARDING_STEPS}
          stepId={doctorOnboarding.currentStepId}
          values={doctorOnboarding.values}
          errors={doctorOnboarding.errors}
          onFieldChange={doctorOnboarding.setFieldValue}
          onNext={doctorOnboarding.next}
          onBack={doctorOnboarding.back}
          onSkip={doctorOnboarding.skip}
          stepNumber={doctorOnboarding.stepNumber}
          totalSteps={doctorOnboarding.totalSteps}
        />
      );
    }

    // Signing in doesn't automatically grant patient data access -- an
    // administrator must add the account first (mirrors the real
    // Doctor Dashboard's admin-approval gate; see mockDoctor.js).
    if (doctorAuth.currentDoctor && !doctorAuth.currentDoctor.accessApproved) {
      return <DoctorAccessPendingScreen doctor={doctorAuth.currentDoctor} onLogout={handleDoctorLogout} />;
    }

    return (
      <>
        <div className="nmpa-screen-only">
          <DoctorHomeSection
            doctor={doctorAuth.currentDoctor}
            onLogout={handleDoctorLogout}
            theme={theme}
            onToggleTheme={toggleTheme}
            onOpenChat={doctorChat.open}
          />
        </div>

        <div className="morphy-widget">
          {doctorChat.isOpen && (
            <DoctorChatPanel
              messages={doctorChat.messages}
              inputValue={doctorChat.inputValue}
              onInputChange={doctorChat.setInputValue}
              onSend={doctorChat.send}
              onSuggestionClick={doctorChat.selectSuggestion}
              onUploadReport={doctorChat.uploadReport}
              isThinking={doctorChat.isThinking}
              onClose={doctorChat.close}
              language={language}
            />
          )}
          <DoctorChatBubbleButton isOpen={doctorChat.isOpen} onToggle={doctorChat.toggle} />
        </div>

        <InstallAppPrompt language={language} />
        <PrintableDoctorPatientReport patient={doctorChat.patientToPrint} />
      </>
    );
  }

  if (role === 'caregiver') {
    if (caregiverAuth.isCheckingSession) {
      return (
        <div className="nmpa-session-loading" role="status" aria-live="polite">
          <p className="nmpa-brand-mark nmpa-brand-mark--lg">NEUROMORPH</p>
          <p className="nmpa-muted">Loading your session…</p>
        </div>
      );
    }
    if (!caregiverAuth.isAuthenticated) {
      return caregiverAuth.view === 'signup' ? (
        <CaregiverSignupScreen
          onSignup={caregiverAuth.signup}
          onSwitchToLogin={() => caregiverAuth.setView('login')}
          onSocialAuth={caregiverAuth.loginWithProvider}
          onBackToRoleGate={() => setRole(null)}
          errors={caregiverAuth.errors}
          isSubmitting={caregiverAuth.isSubmitting}
          theme={theme}
          onToggleTheme={toggleTheme}
          language={language}
          onChangeLanguage={setLanguage}
        />
      ) : (
        <CaregiverLoginScreen
          onLogin={caregiverAuth.login}
          onSwitchToSignup={() => caregiverAuth.setView('signup')}
          onSocialAuth={caregiverAuth.loginWithProvider}
          onBackToRoleGate={() => setRole(null)}
          errors={caregiverAuth.errors}
          isSubmitting={caregiverAuth.isSubmitting}
          theme={theme}
          onToggleTheme={toggleTheme}
          language={language}
          onChangeLanguage={setLanguage}
        />
      );
    }

    // Shown exactly once, right after a fresh caregiver signup -- same
    // pattern as the doctor branch above.
    if (caregiverAuth.currentCaregiver?.onboardingComplete === false) {
      if (caregiverOnboarding.isComplete) {
        return (
          <OnboardingComplete
            wasSkipped={caregiverOnboarding.wasSkipped}
            onContinue={() => caregiverAuth.completeOnboarding(caregiverOnboarding.profile)}
          />
        );
      }
      return (
        <OnboardingStep
          steps={CAREGIVER_ONBOARDING_STEPS}
          stepId={caregiverOnboarding.currentStepId}
          values={caregiverOnboarding.values}
          errors={caregiverOnboarding.errors}
          onFieldChange={caregiverOnboarding.setFieldValue}
          onNext={caregiverOnboarding.next}
          onBack={caregiverOnboarding.back}
          onSkip={caregiverOnboarding.skip}
          stepNumber={caregiverOnboarding.stepNumber}
          totalSteps={caregiverOnboarding.totalSteps}
        />
      );
    }

    // Active retry gate -- a caregiver isn't useful until linked to a real
    // patient (see useCaregiverAuth.js's LINKING NOTE and
    // CaregiverLinkPatientScreen.jsx).
    if (!caregiverAuth.currentCaregiver?.linkedPatientUid) {
      return (
        <CaregiverLinkPatientScreen
          onLink={caregiverAuth.linkToPatient}
          onLogout={handleCaregiverLogout}
          errors={caregiverAuth.errors}
          isSubmitting={caregiverAuth.isSubmitting}
        />
      );
    }

    return (
      <>
        <div className="nmpa-screen-only">
          <CaregiverHomeSection
            self={caregiverSelf}
            rawAnswers={caregiverAuth.currentCaregiver?.today?.completion}
            onAnswer={caregiverAuth.recordCheckInAnswer}
            onOpenChat={caregiverChat.open}
            onLogout={handleCaregiverLogout}
            theme={theme}
            onToggleTheme={toggleTheme}
          />
        </div>

        <div className="morphy-widget">
          {caregiverChat.isOpen && (
            <CaregiverChatPanel
              messages={caregiverChat.messages}
              inputValue={caregiverChat.inputValue}
              onInputChange={caregiverChat.setInputValue}
              onSend={caregiverChat.send}
              onSuggestionClick={caregiverChat.selectSuggestion}
              onUploadReport={caregiverChat.uploadReport}
              isThinking={caregiverChat.isThinking}
              onClose={caregiverChat.close}
              language={language}
            />
          )}
          <CaregiverChatBubbleButton isOpen={caregiverChat.isOpen} onToggle={caregiverChat.toggle} />
        </div>
        <InstallAppPrompt language={language} />
      </>
    );
  }

  if (!auth.isAuthenticated) {
    return auth.view === 'signup' ? (
      <SignupScreen
        onSignup={auth.signup}
        onSwitchToLogin={() => auth.setView('login')}
        onSocialAuth={auth.loginWithProvider}
        errors={auth.errors}
        isSubmitting={auth.isSubmitting}
        theme={theme}
        onToggleTheme={toggleTheme}
        language={language}
        onChangeLanguage={setLanguage}
      />
    ) : (
      <LoginScreen
        onLogin={auth.login}
        onSwitchToSignup={() => auth.setView('signup')}
        onSocialAuth={auth.loginWithProvider}
        errors={auth.errors}
        isSubmitting={auth.isSubmitting}
        theme={theme}
        onToggleTheme={toggleTheme}
        language={language}
        onChangeLanguage={setLanguage}
      />
    );
  }

  // Shown exactly once, right after a fresh signup (never after a login --
  // see MOCK_SELF's default vs. signup()'s explicit override in
  // useAuth.js). Gated on the raw auth flag rather than anything in
  // SelfModel's curated output, since this is an auth-flow concern, not a
  // "cognitive self" one.
  if (auth.currentUser?.onboardingComplete === false) {
    if (onboarding.isComplete) {
      return (
        <OnboardingComplete
          wasSkipped={onboarding.wasSkipped}
          onContinue={() => auth.completeOnboarding(onboarding.profile)}
        />
      );
    }
    return (
      <OnboardingStep
        stepId={onboarding.currentStepId}
        values={onboarding.values}
        errors={onboarding.errors}
        onFieldChange={onboarding.setFieldValue}
        onNext={onboarding.next}
        onBack={onboarding.back}
        onSkip={onboarding.skip}
        stepNumber={onboarding.stepNumber}
        totalSteps={onboarding.totalSteps}
      />
    );
  }

  return (
    <>
      <div className="nmpa-screen-only">
        <DashboardShell activeSection={activeSection} onSelectSection={setActiveSection} userName={self?.name} onLogout={handleLogout} theme={theme} onToggleTheme={toggleTheme} language={language}>
          {activeSection === 'home' && (
            <HomeSection
              self={self}
              onGoToAssessment={() => setActiveSection('assessment')}
              onGoToGames={() => setActiveSection('games')}
              caregiverInviteCode={auth.currentUser?.caregiverInviteCode}
              onGenerateInviteCode={auth.generateCaregiverInviteCode}
              language={language}
            />
          )}
          {activeSection === 'assessment' && (
            <AssessmentSection self={self} assessment={assessment} onGoToProgress={() => setActiveSection('progress')} language={language} />
          )}
          {activeSection === 'games' && (
            <GamesSection
              self={self}
              onCompleteTask={(taskId, score) => auth.recordCompletedDailyTask(taskId, score)}
              onGoToAssessment={() => setActiveSection('assessment')}
              language={language}
            />
          )}
          {activeSection === 'progress' && <ProgressSection self={self} />}
          {activeSection === 'domains' && <DomainsSection self={self} />}
          {activeSection === 'activity' && <ActivitySection self={self} />}
          {activeSection === 'insights' && <InsightsSection self={self} />}
          {activeSection === 'reports' && <ReportsSection self={self} onDownloadReport={handlePrint} />}
          {activeSection === 'morphy' && <MorphySection onOpenChat={chat.open} />}
        </DashboardShell>
      </div>

      <div className="morphy-widget">
        {chat.isOpen && (
          <ChatPanel
            messages={chat.messages}
            inputValue={chat.inputValue}
            onInputChange={chat.setInputValue}
            onSend={chat.send}
            onSuggestionClick={chat.selectSuggestion}
            onUploadReport={chat.uploadReport}
            isThinking={chat.isThinking}
            onClose={chat.close}
            language={language}
          />
        )}
        <ChatBubbleButton isOpen={chat.isOpen} onToggle={chat.toggle} />
      </div>

      <InstallAppPrompt language={language} />

      {/* Sibling of the screen-only wrapper so print.css can hide the
          interactive dashboard and show only this. */}
      <PrintableSelfReport self={self} />
    </>
  );
}
