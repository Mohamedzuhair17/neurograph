import ThemeToggle from '../common/ThemeToggle.jsx';
import CaregiverDailyCheckIn from './CaregiverDailyCheckIn.jsx';
import { useCountUp } from '../../hooks/useCountUp.js';

function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase();
}

function greeting(now = new Date()) {
  const hour = now.getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

// The caregiver counterpart to HomeSection.jsx/DoctorHomeSection.jsx --
// single-screen shell (a caregiver's whole job here is the daily check-in
// + Morphy, no multi-tab nav needed) showing who they're linked to, their
// streak, today's 15-question check-in, and the caregiver assistant.
//
// 2026-08-21: same card-entrance treatment as patient Home (nmpa-anim-fade-up,
// 60ms stagger), plus the same lit-flame + count-up streak number treatment
// HomeSection.jsx uses (nmpa-streak__flame.is-lit, useCountUp) -- same
// "streak" concept, same visual language, not a one-off reinvention.
export default function CaregiverHomeSection({ self, rawAnswers, onAnswer, onOpenChat, onLogout, theme, onToggleTheme }) {
  if (!self) return null;
  const firstName = self.name?.split(' ')[0] || 'there';
  const animatedStreak = useCountUp(self.streak ?? 0);

  return (
    <div className="nmpa-shell">
      <header className="nmpa-topbar">
        <span className="nmpa-brand-mark">NEUROMORPH</span>
        <div className="nmpa-topbar__user">
          {theme && onToggleTheme && <ThemeToggle theme={theme} onToggle={onToggleTheme} size="sm" />}
          <span className="nmpa-avatar" aria-hidden="true">{initials(self.name)}</span>
          <span>{self.name}</span>
          <button type="button" className="nmpa-link" onClick={onLogout}>Log out</button>
        </div>
      </header>

      <main className="nmpa-shell__main nmpa-home">
        <div className="nmpa-home__greeting">
          <p className="nmpa-eyebrow">Caregiver</p>
          <h1 className="nmpa-home__title">{greeting()}, {firstName}.</h1>
        </div>

        <section className="nmpa-card nmpa-home__hero nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '0ms' }}>
          <div>
            <p className="nmpa-eyebrow">Caring for</p>
            <p className="nmpa-home__score" style={{ fontSize: 28 }}>{self.linkedPatientName || 'Not linked'}</p>
            <p className="nmpa-muted">{self.today.completedCount} of {self.today.totalCount} check-in questions done today.</p>
          </div>
          <div className="nmpa-streak">
            <p className="nmpa-streak__count">
              <span className={`nmpa-streak__flame ${self.streak > 0 ? 'is-lit' : ''}`} aria-hidden="true">🔥</span>
              {animatedStreak}
            </p>
            <p className="nmpa-muted">day streak</p>
            {self.streak === 0
              ? <p className="nmpa-muted nmpa-muted--sm">Complete today's check-in to start a streak.</p>
              : <p className="nmpa-muted nmpa-muted--sm">Longest: {self.longestStreak} days</p>}
          </div>
        </section>

        <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '60ms' }}>
          <h2 className="nmpa-card__title">Ask Morphy for Caregivers</h2>
          <p className="nmpa-muted">
            General caregiving guidance, help with the check-in, or questions about how NeuroMorph works -- upload a
            file, use voice input, or just type.
          </p>
          <button type="button" className="nmpa-button nmpa-button--primary" onClick={onOpenChat}>Open Morphy for Caregivers</button>
        </section>

        <section className="nmpa-card nmpa-anim-fade-up" style={{ '--nmpa-anim-delay': '120ms' }}>
          <div className="nmpa-section__header">
            <h2 className="nmpa-card__title">Today's Check-In</h2>
            {self.today.fullyComplete && <span className="nmpa-tag nmpa-tag--info">Done for today</span>}
          </div>
          <p className="nmpa-muted">
            15 questions about how {self.linkedPatientName || 'the patient'} is doing today -- 10 stay the same every
            day, 5 rotate through a wider set. The last one is always optional.
          </p>
          <CaregiverDailyCheckIn checklist={self.today.checklist} answers={rawAnswers} onAnswer={onAnswer} />
        </section>
      </main>
    </div>
  );
}
