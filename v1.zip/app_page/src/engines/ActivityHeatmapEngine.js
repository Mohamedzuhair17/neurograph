import { DailyTaskEngine } from './DailyTaskEngine.js';

const MS_PER_DAY = 24 * 60 * 60 * 1000;

function toDateOnly(d) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}

function isoDate(d) {
  return d.toISOString().slice(0, 10);
}

// Turns completion fraction into a 0-4 intensity bucket for the calendar
// heatmap -- same 5-step scale a GitHub-style contribution graph uses, so
// it reads instantly without a legend.
function intensityFor(fraction) {
  if (fraction <= 0) return 0;
  if (fraction < 0.5) return 1;
  if (fraction < 0.75) return 2;
  if (fraction < 1) return 3;
  return 4;
}

// Builds a calendar-style activity heatmap (like the streak/momentum
// engines, reads raw {date, completion} day records -- never invents a day
// that isn't in the log). Weeks run Sunday -> Saturday; any calendar day in
// range with no matching log entry renders as an empty (hasData: false)
// cell rather than a fabricated zero, so a gap in the data is visibly a
// gap, not indistinguishable from "did nothing that day".
export const ActivityHeatmapEngine = {
  build(activityLog = [], { weeks = 12, asOf } = {}) {
    const byDate = new Map(activityLog.filter((d) => d?.date).map((d) => [d.date, d]));

    let end;
    if (asOf) {
      end = toDateOnly(new Date(asOf));
    } else if (activityLog.length > 0) {
      const latest = activityLog.reduce((max, d) => (d.date > max ? d.date : max), activityLog[0].date);
      end = toDateOnly(new Date(latest));
    } else {
      end = toDateOnly(new Date());
    }
    // Extend to the end of that week (Saturday) so the grid always ends on
    // a full week boundary.
    end = new Date(end.getTime() + (6 - end.getUTCDay()) * MS_PER_DAY);

    const totalDays = weeks * 7;
    const start = new Date(end.getTime() - (totalDays - 1) * MS_PER_DAY);

    const cells = [];
    for (let i = 0; i < totalDays; i++) {
      const day = new Date(start.getTime() + i * MS_PER_DAY);
      const dateStr = isoDate(day);
      const entry = byDate.get(dateStr);
      if (!entry) {
        cells.push({ date: dateStr, hasData: false, intensity: 0, completionPct: 0 });
        continue;
      }
      const fraction = DailyTaskEngine.completionFraction(entry.completion);
      cells.push({ date: dateStr, hasData: true, intensity: intensityFor(fraction), completionPct: Math.round(fraction * 100) });
    }

    const weeksGrid = [];
    for (let w = 0; w < weeks; w++) {
      weeksGrid.push(cells.slice(w * 7, w * 7 + 7));
    }

    const activeDays = cells.filter((c) => c.hasData && c.intensity > 0).length;
    const trackedDays = cells.filter((c) => c.hasData).length;

    return { weeks: weeksGrid, activeDays, trackedDays, startDate: isoDate(start), endDate: isoDate(end) };
  },
};
