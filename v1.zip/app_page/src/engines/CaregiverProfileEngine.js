const toIsoDate = (date) => date.toISOString().slice(0, 10);

// The caregiver counterpart to UserProfileEngine.js -- pure shaping logic
// for a Firestore /caregivers/{uid} document, no Firestore SDK import here
// (same Node-testable convention every engine in this app follows).
// FirestoreCaregiverService.js is the only place that actually talks to
// the database.
export const CaregiverProfileEngine = {
  // linkedPatientUid starts null -- a caregiver account exists the moment
  // they sign up, but isn't useful (and shouldn't show any daily check-in
  // UI) until they've entered a real patient's invite code. See
  // useCaregiverAuth.js for the linking step itself.
  // 2026-08-21: same privacyConsentAcceptedAt treatment as
  // UserProfileEngine.js's buildNewProfileDoc -- see that file's comment.
  buildNewProfileDoc({ name, email, authProvider, privacyConsentAcceptedAt = null } = {}) {
    return {
      name: name || 'there',
      email: email || null,
      authProvider: authProvider || 'password',
      privacyConsentAcceptedAt,
      onboardingComplete: false,
      linkedPatientUid: null,
      linkedPatientName: null,
      today: { date: null, completion: {} },
      dailyHistory: [],
    };
  },

  applyOnboardingProfile(profile, onboardingProfile) {
    return { ...profile, ...onboardingProfile };
  },

  applyPatientLink(profile, patientUid, patientName) {
    return { ...profile, linkedPatientUid: patientUid, linkedPatientName: patientName || null };
  },

  // Marks one daily check-in QUESTION answered for today (mirrors
  // UserProfileEngine.applyDailyTaskCompletion's lazy day-rollover logic
  // exactly, just without a separate performanceScores map -- a caregiver's
  // answer IS the data, there's no secondary "score" to track alongside it).
  applyCheckInAnswer(profile, questionId, value, now = new Date()) {
    const todayDate = toIsoDate(now);
    const isNewDay = profile?.today?.date && profile.today.date !== todayDate;
    const dailyHistory = isNewDay ? [...(profile?.dailyHistory || []), profile.today] : (profile?.dailyHistory || []);
    const baseToday = isNewDay || !profile?.today?.date
      ? { date: todayDate, completion: {} }
      : profile.today;

    const completion = { ...baseToday.completion, [questionId]: value };

    return {
      ...profile,
      today: { ...baseToday, date: todayDate, completion },
      dailyHistory,
    };
  },
};
