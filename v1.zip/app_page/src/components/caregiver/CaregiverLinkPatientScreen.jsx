import { useState } from 'react';
import AuthTextField from '../auth/AuthTextField.jsx';
import { UserIcon } from '../icons/FormIcons.jsx';

// Shown whenever a signed-in caregiver's account isn't linked to a patient
// yet (currentCaregiver.linkedPatientUid is null) -- either they skipped
// the code at signup, or the one they entered didn't resolve. Unlike
// DoctorAccessPendingScreen (a passive wait on an admin), this is an active
// retry screen -- the caregiver can just enter a fresh code and continue,
// since linking is something THEY can complete themselves once the patient
// shares a valid code.
export default function CaregiverLinkPatientScreen({ onLink, onLogout, errors, isSubmitting }) {
  const [code, setCode] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    onLink(code);
  }

  return (
    <div className="nmpa-session-loading" role="status">
      <p className="nmpa-brand-mark nmpa-brand-mark--lg">NEUROMORPH</p>
      <div className="nmpa-card" style={{ maxWidth: 480, textAlign: 'left' }}>
        <h1 className="nmpa-card__title">Link to a patient</h1>
        <p className="nmpa-muted">
          Your account isn't linked to a patient yet. Ask the person you're caring for to open their NeuroMorph app,
          generate an invite code from their home screen, and share it with you.
        </p>
        <form onSubmit={handleSubmit} className="nmpa-form" noValidate>
          <AuthTextField
            icon={<UserIcon />}
            label="Invite code"
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            autoComplete="off"
            autoFocus
            error={errors?.inviteCode}
          />
          <button type="submit" className="nmpa-button nmpa-button--primary nmpa-button--block" disabled={isSubmitting}>
            {isSubmitting ? 'Linking…' : 'Link My Account'}
          </button>
        </form>
        <button type="button" className="nmpa-button nmpa-button--secondary" onClick={onLogout} style={{ marginTop: 12 }}>
          Sign out
        </button>
      </div>
    </div>
  );
}
